# Aloitus
Ensimmäinen Rasekon repositorio
